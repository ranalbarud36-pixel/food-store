﻿using Model;
using System.ServiceModel;

namespace WCFServer
{
    [ServiceContract]
    public interface IService1
    {
        // =========================
        // Admins
        // =========================
        [OperationContract]
        AdminsList AdminsSelectAll();

        [OperationContract]
        Admins AdminsSelect(long id);

        [OperationContract]
        bool AdminsInsert(Admins admin);

        [OperationContract]
        bool AdminsUpdate(Admins admin);

        [OperationContract]
        bool AdminsDelete(long id);

        // =========================
        // Users
        // =========================
        [OperationContract]
        UsersList UsersSelectAll();

        [OperationContract]
        Users UsersSelect(long id);

        [OperationContract]
        bool UsersInsert(Users user);

        [OperationContract]
        bool UsersUpdate(Users user);

        [OperationContract]
        bool UsersDelete(long id);

        [OperationContract]
        Users UsersLogin(string username, string password);

        // =========================
        // FoodItems
        // =========================
        [OperationContract]
        FoodItemsList FoodItemsSelectAll();

        [OperationContract]
        FoodItems FoodItemsSelect(long id);

        [OperationContract]
        bool FoodItemsInsert(FoodItems item);

        [OperationContract]
        bool FoodItemsUpdate(FoodItems item);

        [OperationContract]
        bool FoodItemsDelete(long id);

        // =========================
        // Orders
        // =========================
        [OperationContract]
        OrdersList OrdersSelectAll();

        [OperationContract]
        Orders OrdersSelect(long id);

        [OperationContract]
        bool OrdersInsert(Orders order);

        [OperationContract]
        bool OrdersUpdate(Orders order);

        [OperationContract]
        bool OrdersDelete(long id);

        // =========================
        // OrderDetails
        // =========================
        [OperationContract]
        OrderDetailsList OrderDetailsSelectByOrder(long orderID);

        [OperationContract]
        bool OrderDetailsInsert(OrderDetails detail);

        [OperationContract]
        bool OrderDetailsDelete(long id);
    }
}