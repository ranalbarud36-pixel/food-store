﻿using Model;
using System;
using System.Data.OleDb;
using System.Linq;
using ViewModel;

namespace WCFServer
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in both code and config file together.
    public class Service1 : IService1
    {
        //====================================================== 
        // Admins 
        // ===================================================== 
        public AdminsList AdminsSelectAll()
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                AdminsDB db = new AdminsDB();
                AdminsList list = db.SelectAll();
                ViewModel.DB.CloseDatabase();
                return list;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return null;
            }
        }

        public Admins AdminsSelect(long id)
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                AdminsDB db = new AdminsDB();

                Admins a = new Admins();
                a.ID = id;

                a = (Admins)db.Select(a);

                ViewModel.DB.CloseDatabase();
                return a;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return null;
            }
        }
        public bool AdminsInsert(Admins admin)
        {
            try
            {
                Console.WriteLine($"[WCF] Trying to insert: {admin.Name}, {admin.Mail}, {admin.Phone}, {admin.Username}");
                ViewModel.DB.OpenDatabase();
                AdminsDB adminsDB = new AdminsDB();
                bool result = adminsDB.Insert(admin);
                ViewModel.DB.CloseDatabase();
                General.message = DB.Error;
                Console.WriteLine(result
                                    ? "[WCF] Insert succeeded"
                                    : "[WCF] Insert failed: " + DB.Error);

                return result;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return false;
            }
        }
        public bool AdminsUpdate(Admins admin)
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                AdminsDB adminsDB = new AdminsDB();
                bool result = adminsDB.Update(admin);
                ViewModel.DB.CloseDatabase();
                General.message = DB.Error;
                return result;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return false;
            }
        }
        public bool AdminsDelete(long ID)
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                AdminsDB adminsDB = new AdminsDB();
                Admins admin = new Admins();
                admin.ID = ID;
                bool result = adminsDB.Delete(admin);
                ViewModel.DB.CloseDatabase();
                General.message = DB.Error;
                return result;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return false;
            }
        }

        //public UserLogged AdminsInsertWithPassword(Admins admin)
        //{
        //    password.Type = AdminType();
        //    return SignUp(admin, password);
        //}


        //====================================================== 
        // Users 
        // ===================================================== 
        public UsersList UsersSelectAll()
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                UsersDB db = new UsersDB();
                UsersList list = db.SelectAll();
                ViewModel.DB.CloseDatabase();
                return list;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return null;
            }
        }

        public Users UsersSelect(long id)
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                UsersDB db = new UsersDB();

                Users u = new Users();
                u.ID = id;

                u = (Users)db.Select(u);

                ViewModel.DB.CloseDatabase();
                return u;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return null;
            }
        }
        public bool UsersInsert(Users user)
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                UsersDB db = new UsersDB();
                bool result = db.Insert(user);
                ViewModel.DB.CloseDatabase();
                return result;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return false;
            }
        }
        public bool UsersUpdate(Users user)
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                UserDB usersDB = new UserDB();
                bool result = usersDB.Update(user);
                ViewModel.DB.CloseDatabase();
                General.message = DB.Error;
                return result;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return false;
            }
        }
        public bool UsersDelete(long ID)
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                UserDB usersDB = new UserDB();
                Users user = new Users();
                user.ID = ID;
                bool result = usersDB.Delete(user);
                ViewModel.DB.CloseDatabase();
                General.message = DB.Error;
                return result;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return false;
            }
        }





        //======================================================
        // Users: Check user credintails
        // =====================================================
        public Users UsersLogin(string username, string password)
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                UsersDB db = new UsersDB();

                Users user = db.SelectByUsername(username);

                ViewModel.DB.CloseDatabase();

                if (user == null)
                    return null;

                if (user.Password.Trim() == password.Trim())
                    return user;

                return null;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return null;
            }
        }


        //====================================================== 
        // FOOD ITEMS 
        // ===================================================== 
        public FoodItemsList FoodItemsSelectAll()
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                FoodItemsDB db = new FoodItemsDB();
                FoodItemsList list = db.SelectAll();
                ViewModel.DB.CloseDatabase();
                return list;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return null;
            }
        }

        public FoodItems FoodItemsSelect(long id)
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                FoodItemsDB db = new FoodItemsDB();

                FoodItems item = new FoodItems();
                item.ID = id;

                item = (FoodItems)db.Select(item);

                ViewModel.DB.CloseDatabase();
                return item;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return null;
            }
        }

        public bool FoodItemsInsert(FoodItems item)
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                FoodItemsDB db = new FoodItemsDB();
                bool result = db.Insert(item);
                ViewModel.DB.CloseDatabase();
                return result;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return false;
            }
        }

        public bool FoodItemsUpdate(FoodItems item)
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                FoodItemsDB db = new FoodItemsDB();
                bool result = db.Update(item);
                ViewModel.DB.CloseDatabase();
                return result;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return false;
            }
        }

        public bool FoodItemsDelete(long id)
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                FoodItemsDB db = new FoodItemsDB();

                FoodItems item = new FoodItems();
                item.ID = id;

                bool result = db.Delete(item);

                ViewModel.DB.CloseDatabase();
                return result;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return false;
            }
        }

        //====================================================== 
        // ORDERS 
        // ===================================================== 
        public OrdersList OrdersSelectAll()
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                OrdersDB db = new OrdersDB();
                OrdersList list = db.SelectAll();
                ViewModel.DB.CloseDatabase();
                return list;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return null;
            }
        }

        public Orders OrdersSelect(long id)
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                OrdersDB db = new OrdersDB();

                Orders o = new Orders();
                o.ID = id;

                o = (Orders)db.Select(o);

                ViewModel.DB.CloseDatabase();
                return o;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return null;
            }
        }

        public bool OrdersInsert(Orders order)
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                OrdersDB db = new OrdersDB();
                bool result = db.Insert(order);
                ViewModel.DB.CloseDatabase();
                return result;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return false;
            }
        }

        public bool OrdersUpdate(Orders order)
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                OrdersDB db = new OrdersDB();
                bool result = db.Update(order);
                ViewModel.DB.CloseDatabase();
                return result;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return false;
            }
        }

        public bool OrdersDelete(long id)
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                OrdersDB db = new OrdersDB();

                Orders o = new Orders();
                o.ID = id;

                bool result = db.Delete(o);

                ViewModel.DB.CloseDatabase();
                return result;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return false;
            }
        }

        //====================================================== 
        // ORDER DETAILS 
        // ===================================================== 
        public OrderDetailsList OrderDetailsSelectByOrder(long orderID)
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                OrderDetailsDB db = new OrderDetailsDB();
                OrderDetailsList list = db.SelectByOrder(orderID);
                ViewModel.DB.CloseDatabase();
                return list;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return null;
            }
        }

        public bool OrderDetailsInsert(OrderDetails detail)
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                OrderDetailsDB db = new OrderDetailsDB();
                bool result = db.Insert(detail);
                ViewModel.DB.CloseDatabase();
                return result;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return false;
            }
        }

        public bool OrderDetailsDelete(long id)
        {
            try
            {
                ViewModel.DB.OpenDatabase();
                OrderDetailsDB db = new OrderDetailsDB();

                OrderDetails d = new OrderDetails();
                d.ID = id;

                bool result = db.Delete(d);

                ViewModel.DB.CloseDatabase();
                return result;
            }
            catch (Exception ex)
            {
                General.message = ex.Message;
                return false;
            }
        }

       
        // ===================================================== 
    }
}
