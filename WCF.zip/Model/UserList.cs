﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class UserList : List<Users>
    {
        public UserList()
        {

        }

        public UserList(IEnumerable<Users> list) : base(list)
        {

        }

        public UserList(IEnumerable<BaseEntity> list) : base(list.Cast<Users>().ToList())
        {

        }
    }
}
