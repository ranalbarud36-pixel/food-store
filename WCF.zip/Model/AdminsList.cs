﻿using System.Collections.Generic;
using System.Linq;

namespace Model
{
    public class AdminsList : List<Admins>
    {
        public AdminsList()
        {

        }

        public AdminsList(IEnumerable<Admins> list) : base(list)
        {

        }

        public AdminsList(IEnumerable<BaseEntity> list) : base(list.Cast<Admins>().ToList())
        {

        }
    }
}
