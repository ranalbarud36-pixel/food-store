﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class OrderDetails : BaseEntity
    {
        public long ID { get; set; }
        public long odOrderID { get; set; }
        public long odFoodItemsID { get; set; }
        public int odQuantity { get; set; }

    }
}
