﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class Orders : BaseEntity
    {
        public long ID { get; set; }
        public long oUserID { get; set; }
        public DateTime oDate { get; set; }
        public double oTotalPrice { get; set; }
        public string oStatus { get; set; }

    }
}
