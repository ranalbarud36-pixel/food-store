﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Model
{
    public class FoodItemsList : List<FoodItems>
    {
        public FoodItemsList()
        {

        }

        public FoodItemsList(IEnumerable<FoodItems> list) : base(list)
        {

        }

        public FoodItemsList(IEnumerable<BaseEntity> list) : base(list.Cast<FoodItems>().ToList())
        {

        }
    }
}
