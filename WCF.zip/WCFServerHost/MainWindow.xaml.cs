﻿using System.Windows;
using System.ServiceModel;


namespace WCFServerHost
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        ServiceHost service;
        public MainWindow()
        {
            InitializeComponent();

            ServiceHost service = new ServiceHost(typeof(WCFServer.Service1));
            service.Open();
        }

        private void cmdEnd_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown();
        }
    }
}
