﻿using System;
using System.Data;
using System.Data.OleDb;
using System.IO;

namespace ViewModel
{
    public class DB
    {
        public const string doSelect = "Select";
        public const string doInsert = "Insert";
        public const string doUpdate = "Update";
        public const string doDelete = "Delete";
        public const string doText = "Text";

        public static string Error;
        public static DataTable dbDataTable;

        public static OleDbConnection dbConnection;
        public static OleDbCommand dbCommand;
        public static OleDbDataAdapter dbAdapter;
        public static OleDbDataReader dbReader = null;
        public static OleDbTransaction dbTransaction = null;

        public static bool OpenDatabase()
        {
            // 1. שימוש בטרנזקציית דרייבר נפוצה יותר (אם 16 לא מותקן, 12 יעבוד ולהפך)
            string dbProvider = "Microsoft.ACE.OLEDB.12.0";

            // 2. נתיב דינמי - מחפש את הקובץ Database.accdb בתיקיית הריצה של השרת (bin\Debug)
            // ואם הוא לא שם, נותן נתיב מוחלט זמני כגיבוי
            string dbDatabase = AppDomain.CurrentDomain.BaseDirectory + "Database.accdb";

            // גיבוי: אם הקובץ לא נמצא בתיקיית הריצה, נחפש אותו בתיקיית הפרויקט
            if (!File.Exists(dbDatabase))
            {
                // כאן הגדרתי את השם המדויק של הקובץ שלך: Database.accdb
                dbDatabase = Path.GetFullPath(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"..\..\..\ViewModel\Database.accdb"));
            }

            // אם עדיין לא מצאנו, נשתמש בנתיב פשוט שתוכל לשים בו את הקובץ
            if (!File.Exists(dbDatabase))
            {
                dbDatabase = @"C:\Users\School\Desktop\WCFServer-master\WCFServerHost\App_Data\Database.accdb";
            }

            string ConnString = "Provider=" + dbProvider + ";Data Source=" + dbDatabase;

            dbConnection = new OleDbConnection(ConnString);
            Error = "";
            try
            {
                dbConnection.Open();

                dbCommand = new OleDbCommand
                {
                    Connection = dbConnection
                };
                dbAdapter = new OleDbDataAdapter();
                ParametersClear();
                return true;
            }
            catch (Exception e)
            {
                // אם נכשל ב-12, ננסה עם פרובידר 16
                try
                {
                    ConnString = "Provider=Microsoft.ACE.OLEDB.16.0;Data Source=" + dbDatabase;
                    dbConnection = new OleDbConnection(ConnString);
                    dbConnection.Open();
                    dbCommand = new OleDbCommand { Connection = dbConnection };
                    dbAdapter = new OleDbDataAdapter();
                    ParametersClear();
                    return true;
                }
                catch (Exception ex)
                {
                    Error = "Can't find Data Base " + dbDatabase + ": " + ex.Message;
                    throw new Exception(Error); // זורק שגיאה מפורשת כדי שהשרת לא יקפא ב-Timeout
                }
            }
        }

        public static void CloseDatabase()
        {
            if (dbConnection != null && dbConnection.State == ConnectionState.Open)
                dbConnection.Close();
        }

        public static void BeginTransaction()
        {
            dbTransaction = dbConnection.BeginTransaction();
            dbCommand.Transaction = dbTransaction;
        }

        public static void CommitTransaction()
        {
            if (dbTransaction != null)
            {
                dbTransaction.Commit();
                dbTransaction = null;
                dbCommand.Transaction = null;
            }
        }
        public static void RollbackTransaction()
        {
            if (dbTransaction != null)
            {
                dbTransaction.Rollback();
                dbTransaction = null;
                dbCommand.Transaction = null;
            }
        }
        public static bool Select(string strSQL)
        {
            return OpenDataSet(doSelect, strSQL);
        }
        public static bool Insert(string strSQL)
        {
            return OpenDataSet(doInsert, strSQL);
        }
        public static bool Update(string strSQL)
        {
            return OpenDataSet(doUpdate, strSQL);
        }
        public static bool Delete(string strSQL)
        {
            return OpenDataSet(doDelete, strSQL);
        }
        public static long GetLastKey()
        {
            long LastKey = 0;
            string SQL = "Select @@Identity As LastKey ";
            if (Select(SQL))
            {
                LastKey = Convert.ToInt64(dbDataTable.Rows[0]["LastKey"].ToString());
            }

            return LastKey;
        }
        private static bool OpenDataSet(string Oper, string strSQL)
        {
            dbDataTable = new DataTable();

            try
            {
                if (strSQL.ToUpper().IndexOf("SELECT ") == 0 ||
                    strSQL.ToUpper().IndexOf("INSERT ") == 0 ||
                    strSQL.ToUpper().IndexOf("UPDATE ") == 0 ||
                    strSQL.ToUpper().IndexOf("DELETE ") == 0)
                    dbCommand.CommandType = CommandType.Text;
                else
                    dbCommand.CommandType = CommandType.StoredProcedure;

                dbCommand.CommandText = strSQL;

                switch (Oper)
                {
                    case doInsert:
                        dbAdapter.InsertCommand = dbCommand;
                        break;
                    case doUpdate:
                        dbAdapter.UpdateCommand = dbCommand;
                        break;
                    case doDelete:
                        dbAdapter.DeleteCommand = dbCommand;
                        break;
                    default:
                        dbAdapter.SelectCommand = dbCommand;
                        break;
                }

                if (Oper == doSelect)
                {
                    dbAdapter.Fill(dbDataTable);
                    if (dbDataTable.Rows.Count == 0)
                    {
                        Error = "No Row Found";
                        dbDataTable = null;
                        return false;
                    }
                }
                else
                {
                    dbCommand.ExecuteNonQuery();
                }
                return true;
            }
            catch (Exception e)
            {
                Error = e.Message;
                throw new Exception("SQL Error: " + e.Message); // מונע קפיאה ומציג שגיאה ישירה באתר
            }
        }

        public static void ParametersClear()
        {
            if (dbCommand != null)
                dbCommand.Parameters.Clear();
            else
                throw new InvalidOperationException("dbCommand לא מאותחל. יש לקרוא OpenDatabase() קודם.");
        }

        public static void ParameterAdd(string parName, string parValue)
        {
            dbCommand.Parameters.AddWithValue(parName, parValue);
        }

        public static void ParameterAddBinary(string parName, byte[] parValue)
        {
            if (parValue == null)
                dbCommand.Parameters.AddWithValue(parName, "0");
            else
                dbCommand.Parameters.AddWithValue(parName, parValue);
        }
    }
}