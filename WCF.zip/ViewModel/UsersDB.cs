﻿using Model;
using System;
using System.Data;

namespace ViewModel
{
    public class UsersDB : BaseDB
    {
        public Users user;
        private string SQLSelectByUsername;

        public UsersDB()
        {
            user = new Users();
            InitValues();
        }

        //-----Private---------------------------------------------
        private void InitValues()
        {
            SQLInsert = "Insert Into Users " +
                        "(uName, uPhone, uMail, uUsername, uPassword, uGender) " +
                        "Values (@Name, @Phone, @Mail, @Username, @Password, @Gender) ";

            SQLUpdate = "Update Users Set " +
                            "uName = @Name, " +
                            "uPhone = @Phone, " +
                            "uMail = @Mail, " +
                            "uUsername = @Username, " +
                            "uPassword = @Password, " +
                            "uGender = @Gender " +
                        "Where uID = @ID ";

            SQLDelete = "Delete From Users " +
                        "Where uID = @ID ";

            SQLSelect = "Select * From Users " +
                        "Where uID = @ID ";

            SQLSelectAll = "SELECT * From Users " +
                           "Order By uName, uID ";

            SQLSelectByUsername = "SELECT * From Users " +
                                  "Where uUsername = @Username ";
        }

        protected override void SetParameters(string Oper)
        {
            DB.ParametersClear();

            if (Oper == DB.doDelete ||
                Oper == DB.doSelect)
            {
                DB.ParameterAdd("@ID", user.ID.ToString());
            }

            if (Oper == DB.doInsert ||
                Oper == DB.doUpdate)
            {
                DB.ParameterAdd("@Name", user.Name);
                DB.ParameterAdd("@Phone", user.Phone);
                DB.ParameterAdd("@Mail", user.Mail);
                DB.ParameterAdd("@Username", user.Username);
                DB.ParameterAdd("@Password", user.Password);
                DB.ParameterAdd("@Gender", user.Gender);
            }

            if (Oper == DB.doUpdate)
            {
                DB.ParameterAdd("@ID", user.ID.ToString());
            }
        }

        protected override BaseEntity MoveDBToRecord(DataRow dbRow)
        {
            return MoveDBToRecord(dbRow, user);
        }

        private BaseEntity MoveDBToRecord(DataRow dbRow, Users user)
        {
            user.ID = Convert.ToInt64(dbRow["uID"].ToString());
            user.Name = dbRow["uName"].ToString();
            user.Phone = dbRow["uPhone"].ToString();
            user.Mail = dbRow["uMail"].ToString();
            user.Username = dbRow["uUsername"].ToString();
            user.Password = dbRow["uPassword"].ToString();
            user.Gender = dbRow["uGender"].ToString();

            return user;
        }

        public override void MoveValuesToRecord(BaseEntity userRec)
        {
            user.ID = ((Users)userRec).ID;
            user.Name = ((Users)userRec).Name;
            user.Phone = ((Users)userRec).Phone;
            user.Mail = ((Users)userRec).Mail;
            user.Username = ((Users)userRec).Username;
            user.Password = ((Users)userRec).Password;
            user.Gender = ((Users)userRec).Gender;
        }

        //-----Local--------------------------------------------

        public UsersList SelectAll()
        {
            UsersList usersList = new UsersList();

            string SQL = SQLSelectAll;

            if (!DB.Select(SQL))
            {
                priErrorMessage = DB.Error;
                priErrorNo = -1;
                return new UsersList();
            }

            foreach (DataRow dbRow in DB.dbDataTable.Rows)
            {
                Users user = new Users();
                MoveDBToRecord(dbRow, user);
                usersList.Add(user);
            }

            return usersList;
        }

        public Users SelectByUsername(string Username)
        {
            string SQL = SQLSelectByUsername;

            ErrorClear();

            DB.ParametersClear();
            DB.ParameterAdd("@Username", Username);

            if (!DB.Select(SQL))
            {
                priErrorMessage = DB.Error;
                priErrorNo = -1;
                return null;
            }

            MoveDBToRecord(DB.dbDataTable.Rows[0]);

            return user;
        }
    }
}