﻿using Model;
using System;
using System.Data;

namespace ViewModel
{
    public class OrderDetailsDB : BaseDB
    {
        public OrderDetails orderDetails;

        public OrderDetailsDB()
        {
            orderDetails = new OrderDetails();
            InitValues();
        }

        //-----Private---------------------------------------------
        private void InitValues()
        {
            SQLInsert = "Insert Into OrderDetails " +
                        "(odOrderID, odFoodItemID, odQuantity) " +
                        "Values (@OrderID, @FoodItemID, @Quantity) ";

            SQLUpdate = "Update OrderDetails Set " +
                            "odOrderID = @OrderID, " +
                            "odFoodItemID = @FoodItemID, " +
                            "odQuantity = @Quantity " +
                        "Where odID = @ID ";

            SQLDelete = "Delete From OrderDetails " +
                        "Where odID = @ID ";

            SQLSelect = "Select * From OrderDetails " +
                        "Where odID = @ID ";

            SQLSelectAll = "SELECT * From OrderDetails " +
                           "Order By odID ";
        }

        protected override void SetParameters(string Oper)
        {
            DB.ParametersClear();

            if (Oper == DB.doDelete ||
                Oper == DB.doSelect)
            {
                DB.ParameterAdd("@ID", orderDetails.ID.ToString());
            }

            if (Oper == DB.doInsert ||
                Oper == DB.doUpdate)
            {
                DB.ParameterAdd("@OrderID", orderDetails.odOrderID.ToString());
                DB.ParameterAdd("@FoodItemID", orderDetails.odFoodItemsID.ToString());
                DB.ParameterAdd("@Quantity", orderDetails.odQuantity.ToString());
            }

            if (Oper == DB.doUpdate)
            {
                DB.ParameterAdd("@ID", orderDetails.ID.ToString());
            }
        }

        protected override BaseEntity MoveDBToRecord(DataRow dbRow)
        {
            return MoveDBToRecord(dbRow, orderDetails);
        }

        private BaseEntity MoveDBToRecord(DataRow dbRow, OrderDetails orderDetails)
        {
            orderDetails.ID = Convert.ToInt64(dbRow["odID"].ToString());
            orderDetails.odOrderID = Convert.ToInt64(dbRow["odOrderID"].ToString());
            orderDetails.odFoodItemsID = Convert.ToInt64(dbRow["odFoodItemID"].ToString());
            orderDetails.odQuantity = Convert.ToInt32(dbRow["odQuantity"].ToString());

            return orderDetails;
        }

        public override void MoveValuesToRecord(BaseEntity orderDetailsRec)
        {
            orderDetails.ID = ((OrderDetails)orderDetailsRec).ID;
            orderDetails.odOrderID = ((OrderDetails)orderDetailsRec).odOrderID;
            orderDetails.odFoodItemsID = ((OrderDetails)orderDetailsRec).odFoodItemsID;
            orderDetails.odQuantity = ((OrderDetails)orderDetailsRec).odQuantity;
        }

        //-----Local--------------------------------------------

        public OrderDetailsList SelectAll()
        {
            OrderDetailsList orderDetailsList = new OrderDetailsList();

            string SQL = SQLSelectAll;

            if (!DB.Select(SQL))
            {
                priErrorMessage = DB.Error;
                priErrorNo = -1;
                return new OrderDetailsList();
            }

            foreach (DataRow dbRow in DB.dbDataTable.Rows)
            {
                OrderDetails orderDetails = new OrderDetails();
                MoveDBToRecord(dbRow, orderDetails);
                orderDetailsList.Add(orderDetails);
            }

            return orderDetailsList;
        }
        public OrderDetailsList SelectByOrder(long orderID)
        {
            OrderDetailsList list = new OrderDetailsList();

            string SQL = "SELECT * FROM OrderDetails WHERE odOrderID = @OrderID";

            DB.ParametersClear();
            DB.ParameterAdd("@OrderID", orderID.ToString());

            if (!DB.Select(SQL))
            {
                priErrorMessage = DB.Error;
                priErrorNo = -1;
                return list;
            }

            foreach (DataRow row in DB.dbDataTable.Rows)
            {
                OrderDetails detail = new OrderDetails();
                MoveDBToRecord(row, detail);
                list.Add(detail);
            }

            return list;
        }
    }
}