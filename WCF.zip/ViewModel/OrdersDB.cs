﻿using Model;
using System;
using System.Data;

namespace ViewModel
{
    public class OrdersDB : BaseDB
    {
        public Orders order;

        public OrdersDB()
        {
            order = new Orders();
            InitValues();
        }

        //-----Private---------------------------------------------
        private void InitValues()
        {
            SQLInsert = "Insert Into Orders " +
                        "(oUserID, oDate, oTotalPrice, oStatus) " +
                        "Values (@UserID, @Date, @TotalPrice, @Status) ";

            SQLUpdate = "Update Orders Set " +
                            "oUserID = @UserID, " +
                            "oDate = @Date, " +
                            "oTotalPrice = @TotalPrice, " +
                            "oStatus = @Status " +
                        "Where oID = @ID ";

            SQLDelete = "Delete From Orders " +
                        "Where oID = @ID ";

            SQLSelect = "Select * From Orders " +
                        "Where oID = @ID ";

            SQLSelectAll = "SELECT * From Orders " +
                           "Order By oDate, oID ";
        }

        protected override void SetParameters(string Oper)
        {
            DB.ParametersClear();

            if (Oper == DB.doDelete ||
                Oper == DB.doSelect)
            {
                DB.ParameterAdd("@ID", order.ID.ToString());
            }

            if (Oper == DB.doInsert ||
                Oper == DB.doUpdate)
            {
                DB.ParameterAdd("@UserID", order.oUserID.ToString());
                DB.ParameterAdd("@Date", order.oDate.ToString());
                DB.ParameterAdd("@TotalPrice", order.oTotalPrice.ToString());
                DB.ParameterAdd("@Status", order.oStatus);
            }

            if (Oper == DB.doUpdate)
            {
                DB.ParameterAdd("@ID", order.ID.ToString());
            }
        }

        protected override BaseEntity MoveDBToRecord(DataRow dbRow)
        {
            return MoveDBToRecord(dbRow, order);
        }

        private BaseEntity MoveDBToRecord(DataRow dbRow, Orders order)
        {
            order.ID = Convert.ToInt64(dbRow["oID"].ToString());
            order.oUserID = Convert.ToInt64(dbRow["oUserID"].ToString());
            order.oDate = Convert.ToDateTime(dbRow["oDate"].ToString());
            order.oTotalPrice = Convert.ToDouble(dbRow["oTotalPrice"].ToString());
            order.oStatus = dbRow["oStatus"].ToString();

            return order;
        }

        public override void MoveValuesToRecord(BaseEntity orderRec)
        {
            order.ID = ((Orders)orderRec).ID;
            order.oUserID = ((Orders)orderRec).oUserID;
            order.oDate = ((Orders)orderRec).oDate;
            order.oTotalPrice = ((Orders)orderRec).oTotalPrice;
            order.oStatus = ((Orders)orderRec).oStatus;
        }

        //-----Local--------------------------------------------

        public OrdersList SelectAll()
        {
            OrdersList ordersList = new OrdersList();

            string SQL = SQLSelectAll;

            if (!DB.Select(SQL))
            {
                priErrorMessage = DB.Error;
                priErrorNo = -1;
                return new OrdersList();
            }

            foreach (DataRow dbRow in DB.dbDataTable.Rows)
            {
                Orders order = new Orders();
                MoveDBToRecord(dbRow, order);
                ordersList.Add(order);
            }

            return ordersList;
        }
    }
}