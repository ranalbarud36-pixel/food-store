﻿using Model;
using System;
using System.Data;
namespace ViewModel
{
    public class UserDB : BaseDB
    {
        public Users user;
        private string SQLSelectByUsername;
        public UserDB()
        {
            user = new Users();
            InitValues();
        }

        //-----Private---------------------------------------------
        private void InitValues()
        {
            SQLInsert = "Insert Into users " +
                        "(aName, aPhone, aMail, aUsername, aPassword, aGender) " +
                        "Values (@Name, @Phone, @Mail, @Username, @Password, @Gender) ";

            SQLUpdate = "Update users Set " +
                            "aName = @Name, " +
                            "aPhone = @Phone, " +
                            "aMail = @Mail, " +
                            "aUsername = @Username, " +
                            "aPassword = @Password, " +
                            "aGender = @Gender " +
                        "Where ID = @ID ";

            SQLDelete = "Delete From users " +
                        "Where ID = @ID ";

            SQLSelect = "Select * From users " +
                        "Where ID = @ID ";

            SQLSelectAll = "SELECT * From users " +
                            "Order By aName, ID ";
            SQLSelectByUsername = "SELECT * From users " +
                                    "Where aUsername = @Username ";
        }

        protected override void SetParameters(string Oper)
        {
            DB.ParametersClear();
            if (Oper == DB.doDelete ||
            Oper == DB.doSelect)
            {
                DB.ParameterAdd("@ID", user.ID.ToString());
            }
            if (Oper == DB.doInsert ||
            Oper == DB.doUpdate)
            {
                DB.ParameterAdd("@Name", user.Name);
                DB.ParameterAdd("@Phone", user.Phone);
                DB.ParameterAdd("@Mail", user.Mail);
                DB.ParameterAdd("@Username", user.Username);
                DB.ParameterAdd("@Password", user.Password);
                DB.ParameterAdd("@Gender", user.Gender);
            }
            if (Oper == DB.doUpdate)
            {
                DB.ParameterAdd("@ID", user.ID.ToString());
            }
        }
        protected override BaseEntity MoveDBToRecord(DataRow dbRow)
        {
            return MoveDBToRecord(dbRow, user);
        }

        private BaseEntity MoveDBToRecord(DataRow dbRow, Users user)
        {
            user.ID = Convert.ToInt64(dbRow["ID"].ToString());
            user.Name = dbRow["aName"].ToString();
            user.Phone = dbRow["aPhone"].ToString();
            user.Mail = dbRow["aMail"].ToString();
            user.Username = dbRow["aUsername"].ToString();
            user.Password = dbRow["aPassword"].ToString();
            user.Gender = dbRow["aGender"].ToString();
            return user;
        }

        public override void MoveValuesToRecord(BaseEntity userRec)
        {
            user.ID = ((Users)userRec).ID;
            user.Name = ((Users)userRec).Name;
            user.Phone = ((Users)userRec).Phone;
            user.Mail = ((Users)userRec).Mail;
            user.Username = ((Users)userRec).Username;
            user.Password = ((Users)userRec).Password;
            user.Gender = ((Users)userRec).Gender;
        }

        //-----Local--------------------------------------------
        public UsersList SelectAll()
        {
            UsersList usersList = new UsersList();
            string SQL = SQLSelectAll;
            if (!DB.Select(SQL))
            {
                priErrorMessage = DB.Error;
                priErrorNo = -1;
                return new UsersList();
            }
            foreach (DataRow dbRow in DB.dbDataTable.Rows)
            {
                Users user = new Users();
                MoveDBToRecord(dbRow, user);
                usersList.Add(user);
            }
            return usersList;
        }

        //Passwords רק במחלקות שיש להן קשר לטבלת
        //public Users SelectByUsername(string Username)
        //{
        //    string SQL = SQLSelectByUsername;
        //    ErrorClear();
        //    DB.ParametersClear();
        //    DB.ParameterAdd("@Username", Username);
        //    //if (!DB.Select(SQL))
        //    //{
        //    //    priErrorMessage = DB.Error;
        //    //    priErrorNo = -1;
        //    //    return null;
        //    //}
        //    //  בדיקה שמוודאת שיש לפחות שורה אחת בטבלה
        //    if (!DB.Select(SQL) || DB.dbDataTable.Rows.Count == 0)
        //    {
        //        priErrorMessage = DB.Error;
        //        priErrorNo = -1;
        //        return null; // אם לא נמצא יוזר כזה, נחזיר null
        //    }
        //    MoveDBToRecord(DB.dbDataTable.Rows[0]);
        //    return user;
        //}

        public Users SelectByUsername(string Username)
        {
            string SQL = SQLSelectByUsername;
            ErrorClear();
            DB.ParametersClear();
            DB.ParameterAdd("@Username", Username);

            // הוספנו כאן את בדיקת ה-Rows.Count שמונעת קריסה!
            if (!DB.Select(SQL) || DB.dbDataTable.Rows.Count == 0)
            {
                priErrorMessage = DB.Error;
                priErrorNo = -1;
                return null;
            }

            MoveDBToRecord(DB.dbDataTable.Rows[0]);
            return user;
        }
    }
}