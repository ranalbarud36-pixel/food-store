﻿using Model;
using System;
using System.Data;

namespace ViewModel
{
    public class AdminsDB : BaseDB
    {
        public Admins admin;
        private string SQLSelectByUsername;

        public AdminsDB()
        {
            admin = new Admins();
            InitValues();
        }

        //-----Private---------------------------------------------
        private void InitValues()
        {
            SQLInsert = "Insert Into Admins " +
                        "(aName, aPhone, aMail, aUsername, aPassword) " +
                        "Values (@Name, @Phone, @Mail, @Username, @Password) ";

            SQLUpdate = "Update Admins Set " +
                            "aName = @Name, " +
                            "aPhone = @Phone, " +
                            "aMail = @Mail, " +
                            "aUsername = @Username, " +
                            "aPassword = @Password " +
                        "Where aID = @ID ";

            SQLDelete = "Delete From Admins " +
                        "Where aID = @ID ";

            SQLSelect = "Select * From Admins " +
                        "Where aID = @ID ";

            SQLSelectAll = "SELECT * From Admins " +
                           "Order By aName, aID ";

            SQLSelectByUsername = "SELECT * From Admins " +
                                  "Where aUsername = @Username ";
        }

        protected override void SetParameters(string Oper)
        {
            DB.ParametersClear();

            if (Oper == DB.doDelete ||
                Oper == DB.doSelect)
            {
                DB.ParameterAdd("@ID", admin.ID.ToString());
            }

            if (Oper == DB.doInsert ||
                Oper == DB.doUpdate)
            {
                DB.ParameterAdd("@Name", admin.Name);
                DB.ParameterAdd("@Phone", admin.Phone);
                DB.ParameterAdd("@Mail", admin.Mail);
                DB.ParameterAdd("@Username", admin.Username);
                DB.ParameterAdd("@Password", admin.Password);
            }

            if (Oper == DB.doUpdate)
            {
                DB.ParameterAdd("@ID", admin.ID.ToString());
            }
        }

        protected override BaseEntity MoveDBToRecord(DataRow dbRow)
        {
            return MoveDBToRecord(dbRow, admin);
        }

        private BaseEntity MoveDBToRecord(DataRow dbRow, Admins admin)
        {
            admin.ID = Convert.ToInt64(dbRow["aID"].ToString());
            admin.Name = dbRow["aName"].ToString();
            admin.Phone = dbRow["aPhone"].ToString();
            admin.Mail = dbRow["aMail"].ToString();
            admin.Username = dbRow["aUsername"].ToString();
            admin.Password = dbRow["aPassword"].ToString();

            return admin;
        }

        public override void MoveValuesToRecord(BaseEntity adminRec)
        {
            admin.ID = ((Admins)adminRec).ID;
            admin.Name = ((Admins)adminRec).Name;
            admin.Phone = ((Admins)adminRec).Phone;
            admin.Mail = ((Admins)adminRec).Mail;
            admin.Username = ((Admins)adminRec).Username;
            admin.Password = ((Admins)adminRec).Password;
        }

        //-----Local--------------------------------------------

        public AdminsList SelectAll()
        {
            AdminsList adminsList = new AdminsList();

            string SQL = SQLSelectAll;

            if (!DB.Select(SQL))
            {
                priErrorMessage = DB.Error;
                priErrorNo = -1;
                return new AdminsList();
            }

            foreach (DataRow dbRow in DB.dbDataTable.Rows)
            {
                Admins admin = new Admins();
                MoveDBToRecord(dbRow, admin);
                adminsList.Add(admin);
            }

            return adminsList;
        }

        public Admins SelectByUsername(string Username)
        {
            string SQL = SQLSelectByUsername;

            ErrorClear();
            DB.ParametersClear();
            DB.ParameterAdd("@Username", Username);

            if (!DB.Select(SQL))
            {
                priErrorMessage = DB.Error;
                priErrorNo = -1;
                return null;
            }

            MoveDBToRecord(DB.dbDataTable.Rows[0]);

            return admin;
        }
    }
}