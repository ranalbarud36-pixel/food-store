﻿using Model;
using System;
using System.Data;

namespace ViewModel
{
    public class FoodItemsDB : BaseDB
    {
        public FoodItems foodItem;

        public FoodItemsDB()
        {
            foodItem = new FoodItems();
            InitValues();
        }

        //-----Private---------------------------------------------
        private void InitValues()
        {
            SQLInsert = "Insert Into FoodItems " +
                        "(fName, fDescription, fPrice, fImageURL, fCategory) " +
                        "Values (@Name, @Description, @Price, @ImageURL, @Category) ";

            SQLUpdate = "Update FoodItems Set " +
                            "fName = @Name, " +
                            "fDescription = @Description, " +
                            "fPrice = @Price, " +
                            "fImageURL = @ImageURL, " +
                            "fCategory = @Category " +
                        "Where fID = @ID ";

            SQLDelete = "Delete From FoodItems " +
                        "Where fID = @ID ";

            SQLSelect = "Select * From FoodItems " +
                        "Where fID = @ID ";

            SQLSelectAll = "SELECT * From FoodItems " +
                           "Order By fName, fID ";
        }

        protected override void SetParameters(string Oper)
        {
            DB.ParametersClear();

            if (Oper == DB.doDelete ||
                Oper == DB.doSelect)
            {
                DB.ParameterAdd("@ID", foodItem.ID.ToString());
            }

            if (Oper == DB.doInsert ||
                Oper == DB.doUpdate)
            {
                DB.ParameterAdd("@Name", foodItem.Name);
                DB.ParameterAdd("@Description", foodItem.Description);
                DB.ParameterAdd("@Price", foodItem.Price.ToString());
                DB.ParameterAdd("@ImageURL", foodItem.ImageURL);
                DB.ParameterAdd("@Category", foodItem.Category);
            }

            if (Oper == DB.doUpdate)
            {
                DB.ParameterAdd("@ID", foodItem.ID.ToString());
            }
        }

        protected override BaseEntity MoveDBToRecord(DataRow dbRow)
        {
            return MoveDBToRecord(dbRow, foodItem);
        }

        private BaseEntity MoveDBToRecord(DataRow dbRow, FoodItems foodItem)
        {
            foodItem.ID = Convert.ToInt64(dbRow["fID"].ToString());
            foodItem.Name = dbRow["fName"].ToString();
            foodItem.Description = dbRow["fDescription"].ToString();
            foodItem.Price = Convert.ToDouble(dbRow["fPrice"].ToString());
            foodItem.ImageURL = dbRow["fImageURL"].ToString();
            foodItem.Category = dbRow["fCategory"].ToString();

            return foodItem;
        }

        public override void MoveValuesToRecord(BaseEntity foodItemRec)
        {
            foodItem.ID = ((FoodItems)foodItemRec).ID;
            foodItem.Name = ((FoodItems)foodItemRec).Name;
            foodItem.Description = ((FoodItems)foodItemRec).Description;
            foodItem.Price = ((FoodItems)foodItemRec).Price;
            foodItem.ImageURL = ((FoodItems)foodItemRec).ImageURL;
            foodItem.Category = ((FoodItems)foodItemRec).Category;
        }

        //-----Local--------------------------------------------

        public FoodItemsList SelectAll()
        {
            FoodItemsList foodItemsList = new FoodItemsList();

            string SQL = SQLSelectAll;

            if (!DB.Select(SQL))
            {
                priErrorMessage = DB.Error;
                priErrorNo = -1;
                return new FoodItemsList();
            }

            foreach (DataRow dbRow in DB.dbDataTable.Rows)
            {
                FoodItems foodItem = new FoodItems();
                MoveDBToRecord(dbRow, foodItem);
                foodItemsList.Add(foodItem);
            }

            return foodItemsList;
        }
    }
}