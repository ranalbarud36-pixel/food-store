﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Http;
using System.Linq;

namespace FoodRest_Barud_New.Pages
{
    // הגדרה כללית בתוך ה-Namespace כדי שגם התפריט וגם העגלה יכירו אותה
    public class TempFoodItem
    {
        public long ID { get; set; }
        public string Name { get; set; }
        public double Price { get; set; }
        public string Description { get; set; }
        public string ImageUrl { get; set; }
        public string Category { get; set; }
    }

    public class CartModel : PageModel
    {
        public TempFoodItem ChosenItem { get; set; }

        [BindProperty]
        public int Quantity { get; set; } = 1;

        public string SuccessMessage { get; set; }

        // שנה את הרשימה בתוך ה-CartModel לזו:
        private readonly TempFoodItem[] _hardcodedFoods = new TempFoodItem[]
        {
    new TempFoodItem { ID = 1, Name = "המבורגר קלאסי מפנק", Price = 55, Description = "קציצת בקר 200 גרם בלחמנייה חמה עם ירקות טריים ורוטב הבית", ImageUrl = "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" },
    new TempFoodItem { ID = 2, Name = "צ'יפס קריספי ענק", Price = 22, Description = "תפוחי אדמה איכותיים חתוכים דק, מטוגנים לוהטים ופריכים", ImageUrl = "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" },
    new TempFoodItem { ID = 3, Name = "קוקה קולה זירו", Price = 12, Description = "פחית צוננת של קוקה קולה זירו, מוגשת קר כקרח", ImageUrl = "https://images.unsplash.com/photo-1622483767028-3f66f32aef97?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" }
        };

        public IActionResult OnGet(long foodId)
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("Username")))
            {
                return RedirectToPage("/Account/Login");
            }

            ChosenItem = _hardcodedFoods.FirstOrDefault(f => f.ID == foodId);

            if (ChosenItem == null)
            {
                return RedirectToPage("/Menu");
            }

            return Page();
        }

        public IActionResult OnPost(long foodId)
        {
            ChosenItem = _hardcodedFoods.FirstOrDefault(f => f.ID == foodId);

            if (ChosenItem == null)
                return RedirectToPage("/Menu");

            double totalPrice = ChosenItem.Price * Quantity;
            string username = HttpContext.Session.GetString("Username");

            SuccessMessage = $"הידד {username}! ההזמנה שלך התקבלה בהצלחה! קנית {Quantity} יחידות של '{ChosenItem.Name}' בסך הכל ₪{totalPrice}. השליח כבר בדרך אליך! 🚀🛵";

            return Page();
        }
    }
}